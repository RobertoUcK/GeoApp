package android.RobertoUc.com;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;


public class TrampaActiviy extends SingleFragmentActivity {

    @Override
    public Fragment createFragment(){

        return new TrampaFragment();
    }


}

